5DAE6EC3-A219-4308-B72D-FA0A8A6B4B11		Common Guid shared by sample with multiple languages.
FDD10BFA-E04D-4921-AF44-44A911F26F1B		Unique Guid for each sample regardless of language.
