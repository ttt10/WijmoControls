Please visit http://www.breezejs.com/documentation/start-nuget to learn more.

