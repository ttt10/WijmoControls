"Breeze.Client" ReadMe
------------------------------------------
This Breeze NuGet Package adds essential Breeze javascript files to your project.

For an example of a Breeze application, add the
 'Breeze.WebApi.Sample' package to your project.

Visit http://www.breezejs.com/documentation/start-nuget to learn more.

The following files and references were added to this project.

Scripts

	Scripts/breeze.min.js
	Scripts/breeze.debug.js
	Scripts/breeze.intellisense.js
	Scripts/q.js
	Scripts/q.min.js

