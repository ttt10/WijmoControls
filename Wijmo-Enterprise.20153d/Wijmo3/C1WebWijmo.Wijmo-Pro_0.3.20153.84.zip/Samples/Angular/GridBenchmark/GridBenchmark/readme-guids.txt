BD75EBCE-BF07-40C6-B2AE-7533EEC53FF0		Common Guid shared by sample with multiple languages.
391286EF-DE1F-4DE2-A57D-AFBD2DBCDEC4		Unique Guid for each sample regardless of language.
