771A3DB7-B359-4723-8792-302E59E8388D		Common Guid shared by sample with multiple languages.
69049F1F-5A9B-41C7-A0B4-726A76F39856		Unique Guid for each sample regardless of language.
