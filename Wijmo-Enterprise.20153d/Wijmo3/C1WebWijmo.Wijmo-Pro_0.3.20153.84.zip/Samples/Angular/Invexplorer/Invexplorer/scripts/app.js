"use strict";

// App Module: the name invxApp matches the ng-app attribute in the main <html> tag
// the parameters in the array are the modules that the application depends on (in this case, only "invx").
var app = angular.module("invxApp", ["invx"]);
