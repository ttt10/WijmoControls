Bootstrap Wijmo
--------------------------------------------------------------------------------------------
Use Wijmo with Bootstrap as a Theme

This sample shows how to integrate Bootstrap and Wijmo together. You can optionally use 
Bootstrap instead of a Wijmo Theme. In order to do so, you simply add bootstrap and then our 
integration js and css files.

<product>Wijmo;HTML5</product>