Using Wijmo with AMD
--------------------------------------------------------------------------------------------
Load Wijmo as AMD modules using RequireJS

This sample demonstrates how to use Wijmo as AMD modules. We provide all of our widgets as 
AMD modules. Instead of using large combined files, we recommend using AMD to load only the 
minimum set of widgets you need.

<product>Wijmo;HTML5</product>