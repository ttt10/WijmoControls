39F4E1F6-0FC4-40F8-A800-E43FECD088BF		Common Guid shared by sample with multiple languages.
531F87DA-1998-43EE-A18C-66338D39DA0B		Unique Guid for each sample regardless of language.
